-- MySQL dump 10.13  Distrib 8.0.39, for Win64 (x86_64)
-- 
-- Host: localhost    Database: test
-- ------------------------------------------------------
-- Server version  8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- 
-- Table structure for table `admins`
-- 

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(15) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `admin_password` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;

-- 
-- Dumping data for table `admins`
-- 

LOCK TABLES `admins` WRITE;
INSERT INTO `admins` VALUES (1,'admin','a123');
UNLOCK TABLES;

-- 
-- Table structure for table `cat_infos`
-- 

DROP TABLE IF EXISTS `cat_infos`;
CREATE TABLE `cat_infos` (
  `cat_id` int NOT NULL,
  `cat_race` varchar(50) NOT NULL,
  `cat_name` varchar(100) NOT NULL,
  `cat_sex` varchar(10) NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table `cat_infos`
-- 

LOCK TABLES `cat_infos` WRITE;
INSERT INTO `cat_infos` VALUES (1,'American short-hair','fenda','male'),(2,'American short-hair','kora','female');
UNLOCK TABLES;

-- 
-- Table structure for table `employees`
-- 

DROP TABLE IF EXISTS `employees`;
CREATE TABLE `employees` (
  `emp_id` int NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `emp_position` varchar(100) NOT NULL,
  `emp_salary` decimal(10,2) NOT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table `employees`
-- 

LOCK TABLES `employees` WRITE;
INSERT INTO `employees` VALUES (1,'TONGKeji','internship',300.00),(2,'TANGFaming','internship',300.00);
UNLOCK TABLES;

-- Create `cat_health_records` table
CREATE TABLE IF NOT EXISTS cat_health_records (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    cat_id INT NOT NULL,
    health_check_date DATE NOT NULL,
    weight DECIMAL(5, 2),  -- Weight, with two decimal places
    health_status VARCHAR(255),  -- Health status, e.g., 'Healthy', 'Sick', etc.
    notes TEXT,  -- Notes, to record doctor's suggestions or special circumstances
    FOREIGN KEY (cat_id) REFERENCES cat_infos(cat_id)  -- Links to the `cat_infos` table
);

-- 
-- Table structure for table `financial_records`
-- 

DROP TABLE IF EXISTS `financial_records`;
CREATE TABLE `financial_records` (
  `amount` decimal(10,2) NOT NULL,
  `person_name` varchar(100) NOT NULL,
  `income_expense` varchar(10) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table `financial_records`
-- 

LOCK TABLES `financial_records` WRITE;
INSERT INTO `financial_records` VALUES (100.00,'TONGKeji','Expense','Medical'),(50.00,'TONGKeji','Expense','Food'),(20.00,'TANGFaming','Expense','Daily Necessities'),(1000.00,'School','Income','Donation');
UNLOCK TABLES;

-- Drop `cat_adoptions` table if it exists
DROP TABLE IF EXISTS `cat_adoptions`;

-- Create `cat_adoptions` table with `adoption_status` field
CREATE TABLE `cat_adoptions` (
  `adoption_id` INT NOT NULL AUTO_INCREMENT,
  `cat_id` INT NOT NULL,
  `adopted_by` VARCHAR(100) NOT NULL,
  `adopted_date` DATE NOT NULL,
  `adoption_status` ENUM('Completed', 'Pending') DEFAULT 'Pending',
  PRIMARY KEY (`adoption_id`),
  FOREIGN KEY (`cat_id`) REFERENCES cat_infos (`cat_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create indexes
-- Add an index to the `cat_id` column in the `cat_adoptions` table
CREATE INDEX idx_cat_adoptions_cat_id ON cat_adoptions(cat_id);

-- Add an index to the `person_name` column in the `financial_records` table
CREATE INDEX idx_financial_records_person_name ON financial_records(person_name);

-- Trigger: Check if the cat exists
DELIMITER $$

CREATE TRIGGER before_cat_adopted
BEFORE INSERT ON cat_adoptions
FOR EACH ROW
BEGIN
  DECLARE cat_exists INT;
  -- Check if the cat exists
  SELECT COUNT(*) INTO cat_exists FROM cat_infos WHERE cat_id = NEW.cat_id;
  IF cat_exists = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'The cat does not exist!';
  END IF;
END $$

DELIMITER ;

-- Trigger: Insert financial records without updating `cat_infos` table
DELIMITER $$

CREATE TRIGGER after_cat_adopted
AFTER INSERT ON cat_adoptions
FOR EACH ROW
BEGIN
  -- Insert financial record
  INSERT INTO financial_records (amount, person_name, income_expense, type)
  VALUES (100.00, NEW.adopted_by, 'Income', 'Cat Adoption Fee');
END $$

DELIMITER ;

