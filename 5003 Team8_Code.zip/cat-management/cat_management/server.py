import re  
import flask
import pymysql  
import json
import json
from decimal import Decimal
app = flask.Flask(__name__)
db = pymysql.connect(host='localhost', port=3306, user='root',
                     password='354354ABCabc', database='test_backup', charset='utf8')
cursor = db.cursor()
users = []


@app.route("/", methods=["GET", "POST"])
def login():

    flask.session['login'] = ''
    if flask.request.method == 'POST':
        user = flask.request.values.get("user", "")
        pwd = flask.request.values.get("pwd", "")
        result_user = re.search(r"^[a-zA-Z]+$", user)  
        result_pwd = re.search(r"^[a-zA-Z\d]+$", pwd) 
        if result_user != None and result_pwd != None:  
            msg = 'password wrong'
            sql1 = "select * from admins where admin_name='" + \
                   user + "' and admin_password='" + pwd + "';"
            cursor.execute(sql1)
            result = cursor.fetchone()
            if result:
                flask.session['login'] = 'OK'
                users.append(user)
                return flask.redirect(flask.url_for('cat'))
        else:  
            msg = 'fail'
    else:
        msg = ''
        user = ''
    return flask.render_template('login.html', msg=msg, user=user)



@app.route('/cat', methods=['GET', 'POST'])
def cat():
    if flask.session.get("login", "") == '':
        return flask.redirect('/')

    insert_result = ''
    user_info = users[0] if users else ''

    
    sql_list = """
        SELECT ci.cat_id, ci.cat_race, ci.cat_name, ci.cat_sex,
               COALESCE(ca.adoption_status, 'Pending') AS status
        FROM cat_infos ci
        LEFT JOIN cat_adoptions ca ON ci.cat_id = ca.cat_id
    """

    if flask.request.method == 'GET':
        try:
            cursor.execute(sql_list)
            results = cursor.fetchall()
        except Exception as err:
            print(f"Error fetching cat info: {err}")
            results = []

    if flask.request.method == 'POST':
        cat_id = flask.request.values.get("cat_id", "").strip()
        cat_race = flask.request.values.get("cat_race", "").strip()
        cat_name = flask.request.values.get("cat_name", "").strip()
        cat_sex = flask.request.values.get("cat_sex", "").strip()

   
        if not all([cat_id, cat_race, cat_name, cat_sex]):
            insert_result = "Input cannot be empty."
        else:
            try:
               
                sql_insert = """
                    INSERT INTO cat_infos (cat_id, cat_race, cat_name, cat_sex)
                    VALUES (%s, %s, %s, %s);
                """
                cursor.execute(sql_insert, (cat_id, cat_race, cat_name, cat_sex))
                db.commit()
                insert_result = "Cat added successfully!"
            except Exception as err:
                print(f"Error inserting cat info: {err}")
                db.rollback()
                insert_result = "Failed to add cat."

      
        try:
            cursor.execute(sql_list)
            results = cursor.fetchall()
        except Exception as err:
            print(f"Error fetching cat info after insertion: {err}")
            results = []

    return flask.render_template('cat.html', insert_result=insert_result, user_info=user_info, results=results)

@app.route('/fin', methods=['GET', "POST"])
def fin():
    if flask.session.get("login", "") == '':
        return flask.redirect('/')

    insert_result = ''
    user_info = users[0] if users else ''

    if flask.request.method == 'POST':
        type_ = flask.request.values.get("type", "")
        income_expense = flask.request.values.get("income_expense", "")
        amount = flask.request.values.get("amount", "")
        person_name = flask.request.values.get("person_name", "")

       
        if not all([type_, income_expense, amount, person_name]):
            insert_result = "Input can not null"
        else:
            try:
                amount_decimal = Decimal(amount)
                sql_insert = """
                   INSERT INTO financial_records (amount, person_name, income_expense, type) 
                   VALUES (%s, %s, %s, %s);
                   """
                cursor.execute(sql_insert, (amount_decimal, person_name, income_expense, type_))
                db.commit()
                insert_result = "Sucess!"
            except Exception as err:
                print(err)
                db.rollback()
                insert_result = "Fail"

   
    try:
        sql_list = "SELECT amount, person_name, income_expense, type FROM financial_records;"
        cursor.execute(sql_list)
        results = cursor.fetchall()
    except Exception as err:
        print(err)
        results = []

    return flask.render_template('fin.html', insert_result=insert_result, user_info=user_info, results=results)
@app.route('/emp', methods=['GET', "POST"])
def emp():
    # login session value
    if flask.session.get("login", "") == '':
        
        print('not login!')
        return flask.redirect('/')
    insert_result = ''
    
    if users:
        for user in users:
            user_info = user
    else:
        user_info = ''
    if flask.request.method == 'GET':
        sql_list = "select * from employees"
        cursor.execute(sql_list)
        results = cursor.fetchall()
    if flask.request.method == 'POST':
        emp_id = flask.request.values.get("emp_id", "")
        emp_name = flask.request.values.get("emp_name", "")
        emp_position = flask.request.values.get("emp_position", "")
        emp_salary = flask.request.values.get("emp_salary", "")

        print(emp_id, emp_name, emp_position, emp_salary)
        try:

            sql = """
            CREATE TABLE IF NOT EXISTS employees (
                emp_id INT NOT NULL,
                emp_name VARCHAR(100) NOT NULL, 
                emp_position VARCHAR(100) NOT NULL, 
                emp_salary DECIMAL(10, 2) NOT NULL, 
                PRIMARY KEY (emp_id) 
            ); 
            """
            cursor.execute(sql)
            sql_1 = "insert into employees(emp_id, emp_name, emp_position, emp_salary)values(%s,%s,%s,%s)"
            cursor.execute(sql_1, (emp_id, emp_name, emp_position, emp_salary))
            # result = cursor.fetchone()
            insert_result = "success"
            print(insert_result)
        except Exception as err:
            print(err)
            insert_result = "fail"
            print(insert_result)
            pass
        db.commit()
        sql_list = "select * from employees"
        cursor.execute(sql_list)
        results = cursor.fetchall()
    return flask.render_template('emp.html', insert_result=insert_result, user_info=user_info, results=results)


@app.route('/update_emp', methods=['GET', "POST"])
def update_emp():
    # login session value
    if flask.session.get("login", "") == '':
      
        print('not login!')
        return flask.redirect('/')
    insert_result = ''
   
    if users:
        for user in users:
            user_info = user
    else:
        user_info = ''
    
    if flask.request.method == 'GET':
        sql_list = "select * from employees"
        cursor.execute(sql_list)
        results = cursor.fetchall()
    if flask.request.method == 'POST':
        emp_id = flask.request.values.get("emp_id", "")
        emp_position = flask.request.values.get("emp_position", "")
        emp_salary = flask.request.values.get("emp_salary", "")

    
        select = flask.request.form.get('selected_one')
        if select == 'modify_position':
            try:
                sql = "update employees set emp_position=%s where emp_id=%s;"
                cursor.execute(sql, (emp_position, emp_id))
                insert_result =  emp_id + "success"
            except Exception as err:
                print(err)
                insert_result = "fail!"
                pass
            db.commit()

        if select == 'modify_salary':
            try:
                sql = "update employees set emp_salary=%s where emp_id=%s;"
                cursor.execute(sql, (emp_salary, emp_id))
                insert_result =  emp_id + "success!"
            except Exception as err:
                print(err)
                insert_result = "fail!"
                pass
            db.commit()

        if select == 'delete_emp':
            try:
                sql_delete = "DELETE FROM employees WHERE emp_id='" + emp_id + "';"
                cursor.execute(sql_delete)
                insert_result = "success delete" + emp_id
            except Exception as err:
                print(err)
                insert_result = "fail"
            db.commit()

        else: 
            insert_result = "fail!"
      
        sql_list = "select * from employees"
        cursor.execute(sql_list)
        results = cursor.fetchall()
    return flask.render_template('update_emp.html', user_info=user_info, insert_result=insert_result,
                                 results=results)


@app.route('/adopt_cat', methods=['GET', 'POST'])
def adopt_cat():
  
    if flask.session.get("login", "") == '':
        return flask.redirect('/')

    insert_result = ''  
    user_info = users[0] if users else ''

    if flask.request.method == 'GET':
        try:
            sql_list = """
                SELECT ca.adoption_id, ci.cat_name, ci.cat_race, ca.adopted_by, ca.adopted_date, ca.adoption_status
                FROM cat_adoptions ca
                JOIN cat_infos ci ON ca.cat_id = ci.cat_id
            """
            cursor.execute(sql_list)
            results = cursor.fetchall()
        except Exception as err:
            print(f"Error fetching adoption records: {err}")
            results = []
        return flask.render_template('adopt_cat.html', insert_result=insert_result, user_info=user_info, results=results)

    if flask.request.method == 'POST':
        cat_id = flask.request.values.get("cat_id", "").strip()
        adopted_by = flask.request.values.get("adopted_by", "").strip()
        adopted_date = flask.request.values.get("adopted_date", "").strip()

        if not all([cat_id, adopted_by, adopted_date]):
            insert_result = "Input fields cannot be empty."
        else:
            try:
       
                sql_insert_adoption = """
                    INSERT INTO cat_adoptions (cat_id, adopted_by, adopted_date, adoption_status)
                    VALUES (%s, %s, %s, 'Pending');
                """
                cursor.execute(sql_insert_adoption, (cat_id, adopted_by, adopted_date))
                
                sql_update_status = """
                    UPDATE cat_adoptions
                    SET adoption_status = 'Completed'
                    WHERE cat_id = %s;
                """
                cursor.execute(sql_update_status, (cat_id,))

                db.commit()
                insert_result = "Adoption completed successfully."
            except Exception as err:
                print(f"Error during adoption process: {err}")
                db.rollback()
                insert_result = "Failed to process adoption request."

        try:
            sql_list = """
                SELECT ca.adoption_id, ci.cat_name, ci.cat_race, ca.adopted_by, ca.adopted_date, ca.adoption_status
                FROM cat_adoptions ca
                JOIN cat_infos ci ON ca.cat_id = ci.cat_id
            """
            cursor.execute(sql_list)
            results = cursor.fetchall()
        except Exception as err:
            print(f"Error fetching updated adoption records: {err}")
            results = []

    return flask.render_template('adopt_cat.html', insert_result=insert_result, user_info=user_info, results=results)

@app.route('/health_records', methods=['GET', 'POST'])
def health_records():
    if flask.session.get("login", "") == '':
        return flask.redirect('/')

    insert_result = ''
    if users:
        for user in users:
            user_info = user
    else:
        user_info = ''

    if flask.request.method == 'GET':
        # get the all cat healthy record
        sql_list = "SELECT * FROM cat_health_records"
        cursor.execute(sql_list)
        results = cursor.fetchall()

    if flask.request.method == 'POST':
        cat_id = flask.request.values.get("cat_id", "")
        health_check_date = flask.request.values.get("health_check_date", "")
        weight = flask.request.values.get("weight", "")
        health_status = flask.request.values.get("health_status", "")
        notes = flask.request.values.get("notes", "")

        # check if the input is null
        if not all([cat_id, health_check_date, weight, health_status]):
            insert_result = "Input is null"
        else:
            try:
                # insert the healthy record into `cat_health_records` table
                sql_1 = """
                INSERT INTO cat_health_records (cat_id, health_check_date, weight, health_status, notes)
                VALUES (%s, %s, %s, %s, %s)
                """
                cursor.execute(sql_1, (cat_id, health_check_date, weight, health_status, notes))
                db.commit()
                insert_result = "Health record added successfully"
            except Exception as err:
                print(err)
                insert_result = "fail"
                db.rollback()

        # get the latest  cat healthy record
        sql_list = "SELECT * FROM cat_health_records"
        cursor.execute(sql_list)
        results = cursor.fetchall()

    return flask.render_template('health_records.html', insert_result=insert_result, user_info=user_info, results=results)



@app.route('/update_cat', methods=['GET', 'POST'])
def update_cat():
    if flask.session.get("login", "") == '':
        return flask.redirect('/')

    insert_result = ''
    if flask.request.method == 'GET':
        sql_list = "SELECT * FROM cat_infos"
        cursor.execute(sql_list)
        results = cursor.fetchall()

    if users:
        for user in users:
            user_info = user
    else:
        user_info = ''

    if flask.request.method == 'POST':
        cat_id = flask.request.values.get("cat_id", "")
        cat_race = flask.request.values.get("cat_race", "")
        cat_name = flask.request.values.get("cat_name", "")

        select = flask.request.form.get('selected_one')
        if select == 'modifying_race':
            try:
                sql = "UPDATE cat_infos SET cat_race=%s WHERE cat_id=%s;"
                cursor.execute(sql, (cat_race, cat_id))
                insert_result = cat_id + " success"
            except Exception as err:
                print(err)
                insert_result = "fail"
            db.commit()

        if select == 'modifying_name':
            try:
                sql = "UPDATE cat_infos SET cat_name=%s WHERE cat_id=%s;"
                cursor.execute(sql, (cat_name, cat_id))
                insert_result = cat_name + " success!"
            except Exception as err:
                print(err)
                insert_result = "fail"
            db.commit()

        if select == 'delete_cat':
            try:
                sql_delete = "DELETE FROM cat_infos WHERE cat_id=%s;"
                cursor.execute(sql_delete, (cat_id,))
                insert_result = "success delete " + cat_id
            except Exception as err:
                print(err)
                insert_result = "fail"
            db.commit()

        sql_list = "SELECT * FROM cat_infos"
        cursor.execute(sql_list)
        results = cursor.fetchall()

    return flask.render_template('update_cat.html', user_info=user_info, insert_result=insert_result, results=results)


# Starting
app.debug = True
app.secret_key = 'carson'
try:
    app.run()
except Exception as err:
    print(err)
    db.close()
